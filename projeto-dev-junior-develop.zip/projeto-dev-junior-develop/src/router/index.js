import { createRouter, createWebHistory } from 'vue-router';
import Clientes from '../views/clientes/Index.vue';
import Dashboard from '../views/dashboard/Index.vue';
import Autenticacao from '../views/autenticacao/Login.vue';
import vendas from '../views/vendas/Index.vue';
import NotFound from '@/components/layouts/NotFoundLayout.vue'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: Autenticacao,
    meta: {layout: "blank"}
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: Dashboard,
    meta: { requiresAuth: true }
  },
  {
    path: '/clientes',
    name: 'Clientes',
     component: Clientes,
     meta: { requiresAuth: true }
    },
  {
    path: '/vendas',
    name: 'Vendas',
    component: vendas,
    meta: { requiresAuth: true }
  },
  {
    path: '/:catchAll(.*)',
    name:  'NotFound',
    component: NotFound,
    meta: { layout: "blank"}
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

router.beforeEach((to, from, next) => {
  const isAuthenticated = localStorage.getItem('authToken') !== null;

  if (to.meta.requiresAuth && !isAuthenticated) {
    next('/login');
  } else {
    next();
  }
});

export default router;