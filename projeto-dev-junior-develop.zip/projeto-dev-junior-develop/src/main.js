import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'
import router from './router/index.js'
import DefaultLayout from './components/layouts/DefaultLayout.vue'
import BlankLayout from './components/layouts/BlankLayout.vue'
import NotFound from '@/components/layouts/NotFoundLayout.vue'

const app = createApp(App).component('default-layout', DefaultLayout).component('blank-layout', BlankLayout).component('not-found', NotFound)

app.use(router)
app.mount('#app')
