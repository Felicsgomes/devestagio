<template>
  <button :class="['btn-profile', colorClass]" v-bind="attrs">
    <slot>{{ name }}</slot>
  </button>
</template>

<script setup>
import { defineProps, computed, useAttrs } from "vue";
const attrs = useAttrs(); //permite que o elemento tenha acesso a qualquer propriedade 
const props = defineProps({ //definição da propriedade
  name: String,
  colorButton: String,
});

const colorClass = computed(() => {
  if (props.colorButton === "green") {
    return "btn-green";
  }
  if (props.colorButton === "gray") {
    return "btn-gray";
  }
  if(props.colorButton === "red") {
    return "btn-red";
  }
  return "";
});

</script>

<style scoped src="./Button.css">
</style>
