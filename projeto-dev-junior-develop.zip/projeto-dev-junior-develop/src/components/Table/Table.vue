<template>
  <div class="container">
    <div class="table-wrapper">
      <table class="table">
        <thead class="table-head">
          <tr>
            <th v-for="header in headers" :key="header.key">
              {{ header.label }}
            </th>
           
            <th v-if="$slots.actions" class="actions-header">
              Ações
            </th>
          </tr>
        </thead>
        <tbody class="table-body">
          <tr v-for="(row, rowIndex) in rows" :key="row.id" class="table-row">
            <td v-for="header in headers" :key="header.key">
              <span class="table-data-text">
                {{ row[header.key] }}
              </span>
            </td>
         
            <td v-if="$slots.actions" class="actions">
              <slot name="actions" :row="row" :rowIndex="rowIndex" />
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup>
import { defineProps } from "vue";

const props = defineProps({
  headers: Array,
  rows: Array
});
</script>

<style scoped src="./Table.css">

</style>
