<template>
  <header class="header">
    <div class="profile">
      <div>
        <img
          src="../../assets/icons/Genearafoto.png"
          class="profile-image"
          alt="profile"
        />
      </div>
      <div class="name">
        <strong>Olá {{ userEmail }}</strong>
        <span class="header-logout" @click="logout">Sair</span>
      </div>
    </div>
    <Button colorButton="gray" @click="goToDashboard">Voltar</Button>
  </header>
</template>

<script setup>
import { computed } from "vue";
import Button from "../Button/Button.vue";

// Composable para gerenciar o usuário
const useUser = () => {
  const user = JSON.parse(localStorage.getItem("authUser")) || {};
  return { email: user.email || '' };
};

const { email: userEmail } = useUser();

const logout = () => {
  localStorage.removeItem("authToken");
  window.location.href = "/login";
};

const goToDashboard = () => {
  window.location.href = "/dashboard";
};
</script>

<style scoped src="./Header.css">

</style>
