<template>
 <svg width="16" height="17" viewBox="0 0 16 17" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_1593_170)">
<path d="M5.99998 15.46C6.36817 15.46 6.66665 15.1616 6.66665 14.7934C6.66665 14.4252 6.36817 14.1267 5.99998 14.1267C5.63179 14.1267 5.33331 14.4252 5.33331 14.7934C5.33331 15.1616 5.63179 15.46 5.99998 15.46Z" stroke="white" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M13.3334 15.46C13.7015 15.46 14 15.1616 14 14.7934C14 14.4252 13.7015 14.1267 13.3334 14.1267C12.9652 14.1267 12.6667 14.4252 12.6667 14.7934C12.6667 15.1616 12.9652 15.46 13.3334 15.46Z" stroke="white" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M0.666687 1.46021H3.33335L5.12002 10.3869C5.18098 10.6938 5.34796 10.9695 5.59172 11.1657C5.83548 11.362 6.14049 11.4662 6.45335 11.4602H12.9334C13.2462 11.4662 13.5512 11.362 13.795 11.1657C14.0387 10.9695 14.2057 10.6938 14.2667 10.3869L15.3334 4.79354H4.00002" stroke="white" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_1593_170">
<rect width="16" height="16" fill="white" transform="translate(0 0.793457)"/>
</clipPath>
</defs>
</svg>
</template>