<template>
    <svg width="27" height="24" viewBox="0 0 27 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
            d="M12.5387 18.4775C17.1961 18.4775 20.9717 14.9943 20.9717 10.6975C20.9717 6.40071 17.1961 2.91748 12.5387 2.91748C7.88129 2.91748 4.10571 6.40071 4.10571 10.6975C4.10571 14.9943 7.88129 18.4775 12.5387 18.4775Z"
            stroke="#E5EBF1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M23.0799 20.4225L18.4945 16.1921" stroke="#E5EBF1" stroke-width="2" stroke-linecap="round"
            stroke-linejoin="round" />
    </svg>
</template>