<template>
  <div class="layout">
    <Sidebar />
    <div class="main-content">
      <Header />
      <div class="container-view">
      <router-view/>
      </div>

     <Footer/>      
    </div>
  </div>
</template>
<script setup>
import Sidebar from "../Sidebar/Sidebar.vue";
import Header from "../Header/Header.vue";
import Footer from "../Footer/Footer.vue";
</script>
<style>
.layout {
  display: flex;
  background: #F5F5F5;
  height: 100vh;
  width: 100vw;
}
.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
}
.container-view {
  width: 100%;
  height: 100%;
  overflow-y: scroll;
  padding: 10px;
  margin-bottom: 50px;
}
</style>
