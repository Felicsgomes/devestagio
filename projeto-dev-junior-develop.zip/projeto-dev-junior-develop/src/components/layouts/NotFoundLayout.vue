<template>
  <div class="title">
    <h1 class="title-text">Pagina não encontrada</h1>
  </div>
</template>
<script setup></script>
<style scoped>
.title {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  color: black;
}
.title-text {
  font-size: 2rem;
  font-weight: 700;
  font-family: "Jost", sans-serif;
}
</style>
