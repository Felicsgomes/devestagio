<template>
  <aside class="sidebar">
    <div class="logo">
    <a href="/dashboard">
      <LogoIcon />
    </a>

    </div>
    <nav class="menu">
      <div class="menu-item">
        <router-link to="/dashboard">
          <DashboardIcon />
          <span class="menu-text"> Dashboard </span>
        </router-link>
      </div>

      <div class="menu-item">
        <router-link to="/clientes">
          <PeopleIcon />
          <span class="menu-text"> Clientes </span>
        </router-link>
      </div>

      <div class="menu-item">
        <router-link to="/vendas">
          <CardIcon />
          <span class="menu-text"> Vendas </span>
        </router-link>
      </div>
    </nav>
  </aside>
</template>
<script setup>
import LogoIcon from "../icons/LogoIcon.vue";
import CardIcon from "../icons/CartIcon.vue";
import DashboardIcon from "../icons/DashboardIcon.vue";
import PeopleIcon from "../icons/PeopleIcon.vue";
</script>
<style scoped src="./Sidebar.css">

</style>
