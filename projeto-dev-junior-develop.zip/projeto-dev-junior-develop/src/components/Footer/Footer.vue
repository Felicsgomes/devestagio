<template>
    <footer class="footer">

        <strong> © Lyncas - 2024</strong>
    </footer>
</template>

<style scoped src="./Footer.css">
</style>