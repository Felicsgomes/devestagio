export const formatDateBRL = (date) => {
    const [year, month, day] = date.split("-");
    return `${day}/${month}/${year}`;
  };
  
  export const formatPriceBRL = (value) => {
    if (isNaN(value)) return "R$ 0,00";
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
  };
  


export function formatCPF(cpf) {
    cpf = cpf.replace(/\D/g, '').slice(0, 11);
    return cpf
      .replace(/(\d{3})(\d{3})/, '$1.$2.')
      .replace(/\.(\d{3})(\d{1,2})/, '.$1-$2');
  }
  
  export function formatPhoneNumber(phone) {
    phone = phone.replace(/\D/g, '').slice(0, 11);
    return phone
      .replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3')
      .replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3'); 
  }
  