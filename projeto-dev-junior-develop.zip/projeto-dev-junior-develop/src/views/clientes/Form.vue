<template>
    <div class="container">
        <h1 class="title">{{ formTitle }}</h1>
        <div>
            <form class="form" @submit.prevent="submitForm">
                <div class="form-group">
                    <label>Nome</label>
                    <input class="input" v-model="formData.name" type="text" />
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input class="input" v-model="formData.email" type="text" />
                </div>
                <div class="form-group">
                    <label>Telefone</label>
                    <input class="input" :value="formatPhoneNumber(formData.tel)"
                        @input="updateTel($event.target.value)" type="text" />
                </div>
                <div class="form-group">
                    <label>CPF</label>
                    <input class="input" :value="formatCPF(formData.cpf)" @input="updateCpf($event.target.value)"
                        type="text" />
                </div>
                <div class="form-group-button">
                    <Button type="submit" colorButton="green">Salvar</Button>
                    <Button type="button" colorButton="red" @click="$emit('close')">Cancelar</Button>
                </div>
            </form>
        </div>
    </div>
</template>

<script setup>
import { ref, defineProps, defineEmits, watch, computed } from "vue";
import axios from "axios";
import Button from "@/components/Button/Button.vue";
import { formatCPF, formatPhoneNumber } from "@/utils/format";

const props = defineProps({
    client: Object,
});

const emit = defineEmits(["close"]);

const formData = ref({
    name: "",
    email: "",
    tel: "",
    cpf: "",
});

// computed para pegar o nome do formulario
const formTitle = computed(() => {
    return props.client ? "Editar Cliente" : "Adicionar Cliente";
});
function updateTel(value) {
    formData.value.tel = value.replace(/\D/g, '');
}

function updateCpf(value) {
    formData.value.cpf = value.replace(/\D/g, '');
}

// watch para quando a props for alterada ele vai atualizar o formaData
watch(
    () => props.client,
    (newClient) => {
        if (newClient) {
            formData.value = { ...newClient };
        } else {
            formData.value = {
                name: "",
                email: "",
                tel: "",
                cpf: "",
            };
        }
    }
);

async function submitForm() {
    if(!formData.value.name || !formData.value.email || !formData.value.tel || !formData.value.cpf) {
        alert("Preencha todos os campos");
        return
    }
    if (props.client) {
        // se tiver a props client significa que estou editando entao faz a request de edição
        await axios
            .put(`http://localhost:3005/clients/${props.client.id}`, formData.value)
            .then(() => {
                alert("Editado com sucesso");
                emit("close");
            })
            .catch((err) => {
                console.error(err);
            });
    } else {
        // caso ao inves de editar que seja para adicionar
        await axios
            .post("http://localhost:3005/clients", formData.value)
            .then(() => {
                alert("Cadastrado com sucesso");
                emit("close");
            })
            .catch((err) => {
                console.error(err);
            });
    }
}
</script>

<style scoped>
.container {
    margin: 10px;
    background-color: #ffffff;
    border: solid 1px #e5ebf1;
    border-radius: 5px;
    box-shadow: 1px 1px 1px 1px #e5ebf1;
    padding: 35px;
}

.title {
    color: #26324b;
    font-size: 20px;
    font-weight: 700;
    font-family: "Jost", sans-serif;
    margin-bottom: 25px;
}

.input {
    width: 100%;
    height: 38px;
    border: solid 1px #e5ebf1;
    border-radius: 5px;
    padding: 10px;
}

.form {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.form-group {
    flex: 1 1 calc(50% - 20px);
    display: flex;
    flex-direction: column;
}

.form-group-button {
    display: flex;
    justify-content: flex-end;
    gap: 20px;
    flex: 1 1 100%;
}

@media (max-width: 600px) {
    .form-group {
        flex: 1 1 100%;
    }
}
</style>