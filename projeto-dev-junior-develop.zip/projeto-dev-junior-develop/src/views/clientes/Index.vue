<template>
  <div>
    <div v-if="!openForm">
      <div class="container-search">
        <div class="search-wrapper">
          <input
            type="search"
            name="search"
            class="input-search"
            v-model="searchTerm"
            placeholder="Pesquisar..."
          />
          <SearchIcon class="search-icon" />
        </div>
      </div>
      <div class="container-button">
        <Button colorButton="green" @click="toggleForm">Adicionar</Button>
      </div>
      <Table :headers="headers" :rows="filteredRows">
        <template v-slot:actions="{ row }">
          <button
            @click="editClient(row.id)"
            class="btn-edit"
            aria-label="Editar Cliente"
          >
            Editar
          </button>
          <button
            @click="deleteClient(row.id)"
            class="btn-delete"
            aria-label="Deletar Cliente"
          >
            Deletar
          </button>
        </template>
      </Table>
    </div>
    <div v-show="openForm">
      <Form :client="selectedClient" @close="toggleForm" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, computed } from "vue";
import axios from "axios";
import Table from "@/components/Table/Table.vue";
import Button from "@/components/Button/Button.vue";
import Form from "@/views/clientes/Form.vue";
import { formatPhoneNumber, formatCPF } from "@/utils/format";
import SearchIcon from "@/components/icons/SearchIcon.vue";

const openForm = ref(false);
const selectedClient = ref(null);
const headers = ref([
  { key: "id", label: "ID" },
  { key: "name", label: "Nome" },
  { key: "email", label: "Email" },
  { key: "tel", label: "Telefone" },
  { key: "cpf", label: "CPF" },
]);
const rows = ref([]);
const searchTerm = ref("");

const formattedRows = computed(() => {
  return rows.value.map(row => ({
    ...row,
    tel: formatPhoneNumber(row.tel),
    cpf: formatCPF(row.cpf)
  }));
});

const filteredRows = computed(() => {
  const term = searchTerm.value.toLowerCase();
  return formattedRows.value.filter(row =>
    Object.values(row).some(value =>
      String(value).toLowerCase().includes(term)
    )
  );
});
// requisiçoes http
// get, post, put, delete
// crud = create, read, update, delete
// resquest response
//funções pra consumir API
async function getClients() {
  await axios.get("http://localhost:3005/clients") //função assíncronas para listar os clientes. awaiit = aguardando a função axios.get
    .then((res) => {  
      console.log('retorno da api de clientes',res.data)                             //then caso de sucesso   
      rows.value = res.data
    })
    .catch((err) => {
      console.error(err);
    });
}

async function editClient(id) {
  await axios.get(`http://localhost:3005/clients/${id}`).then((res) => {
      selectedClient.value = res.data;
      openForm.value = true;
    })
    .catch((err) => {
      console.error(err);
    });
}

async function deleteClient(id) {
  if (confirm("Tem certeza de que deseja excluir este cliente?")) {
    await axios.delete(`http://localhost:3005/clients/${id}`).then(() => {
        rows.value = rows.value.filter((client) => client.id !== id); //filtra oq foi deletado e atualiza a tabela
      }) 
      .catch((err) => {
        console.error(err);
      });
  }
}

function toggleForm() {
  openForm.value = !openForm.value;
  if (!openForm.value) {
    selectedClient.value = null;
  }
}

// ele executa  a função getClients quando o componente estiver montado
onMounted(getClients);
//
// watch para monitorar as mudanças para atualizar a tabela
watch(openForm, getClients);
</script>

<style scoped>
.container-search {
  display: flex;
  justify-content: end;
}

.search-wrapper {
  width: 30%;
  position: relative;
  display: flex;
  align-items: center;
}

.input-search {
  width: 100%;
  margin: 10px;
  padding: 10px;
  border-radius: 5px;
  padding-right: 40px;
}

.search-icon {
  position: absolute;
  right: 10px;
  font-size: 1.2em; 
  color: #999; 
}
.container-button {
  display: flex;
  justify-content: flex-end;
  margin: 20px;
}

.btn-edit {
  padding: 9px;
  background-color: #f6fafd;
  color: #5b89c7;
  border-radius: 5px;
  font-weight: 500;
  font-size: 14px;
  font-family: "Jost", sans-serif;
  cursor: pointer;
}

.btn-delete {
  padding: 9px;
  background-color: #fdf6f6;
  color: #c27476;
  border-radius: 5px;
  font-weight: 500;
  font-size: 14px;
  font-family: "Jost", sans-serif;
  cursor: pointer;
}
</style>
