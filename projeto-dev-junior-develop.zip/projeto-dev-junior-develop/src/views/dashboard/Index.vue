<template>
  <div class="title">Bem vindo!
  </div>
</template>

<script setup>

</script>

<style scoped>
.title{
  color: #26324B;
  display: flex;
  justify-content: center;
  align-items: center;
  height: calc(100vh - 300px);
  font-size: 20px;
  font-weight: bold;
  font-family: "Jost", sans-serif;
}
</style>