<template>
  <div class="container-pagina">
    <div class="container-login">
      <div class="secao-boas-vindas">
        <img src="../../assets/icons/lyncaslogo1.png" alt="Logo Lyncas" class="logo" />
        <p class="texto-boas-vindas">
          Bem-vindo ao Lyncas Sales, uma aplicação simples para gerenciar vendas e
          clientes.
        </p>
      </div>
      <div class="secao-login">
        <form @submit.prevent="validarFormulario">
          <h2 class="titulo-login">Entrar</h2>
          <input
            type="email"
            id="email"
            class="campo-input"
            placeholder="E-mail"
            v-model="email"
            :class="{ erro: emailErro }"
          />
          <input
            type="password"
            id="senha"
            class="campo-input"
            placeholder="Senha"
            v-model="senha"
            :class="{ erro: senhaErro }"
          />
          <div class="botao-container">
            <button type="submit" class="botao-login">Entrar</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>
<script>
import { defineComponent, ref } from "vue";
export default defineComponent({
  name: "Login",
  setup() {
    const email = ref("");
    const senha = ref("");
    const emailErro = ref(false);
    const senhaErro = ref(false);

    const validarFormulario = () => {
      let valid = true;

      if (!email.value) {
        emailErro.value = true;
        valid = false;
      } else {
        emailErro.value = false;
      }

      if (!senha.value) {
        senhaErro.value = true;
        valid = false;
      } else {
        senhaErro.value = false;
      }

      if (valid) {
        const fakeToken = "HashiwjTokenFake";
        localStorage.setItem("authToken", fakeToken);
        localStorage.setItem("authUser", JSON.stringify({ email: email.value }));
        window.location.href = "/dashboard";
      }
    };

    return {
      email,
      senha,
      emailErro,
      senhaErro,
      validarFormulario,
    };
  },
});
</script>
<style scoped>
.container-pagina {
  width: 100%;
  height: 100vh;
  background-color: #f8f8f8;
}
.container-login {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.secao-boas-vindas {
  background-color: #274a9d;
  color: #fff;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 20px;
}

.logo {
  width: 150px;
  margin-bottom: 20px;
}

.texto-boas-vindas {
  font-size: 24px;
  font-family: "Jost", sans-serif;
  font-weight: 500;
  line-height: 34.68px;
  text-align: center;
  width: 100%;
}

.secao-login {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 20px;
}

.formulario-login {
  width: 100%;
  max-width: 400px;
  text-align: center;
}

.titulo-login {
  display: flex;
  justify-content: center;
  font-size: 2em;
  margin-bottom: 20px;
  color: #26324b;
  font-size: 40px;
  font-family: "Jost", sans-serif;
}

.campo-input {
  width: 100%;
  height: 38px;
  padding: 10px;
  margin-bottom: 20px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 1em;
  font-family: "Jost", sans-serif;
  font-family: "Jost", sans-serif;
}

.campo-input.erro {
  border-color: red;
}

.botao-container {
  display: flex;
  justify-content: end;
}

.botao-login {
  width: 94px;
  height: 33px;
  background-color: #03c874;
  color: #fff;
  border: none;
  border-radius: 4px;
  font-size: 1.2em;
  font-family: "Jost", sans-serif;
  cursor: pointer;
}

/* Media queries para responsividade */
@media (min-width: 768px) {
  .container-login {
    flex-direction: row;
    height: 100vh;
  }

  .secao-boas-vindas,
  .secao-login {
    flex: 1;
    height: auto;
  }

  .logo {
    width: 200px;
  }

  .texto-boas-vindas {
    width: 80%;
  }
}
@media (max-width: 768px) {
  .secao-boas-vindas {
    height: 364px;
  }
  .titulo-login {
    font-size: 35px;
    font-weight: 500;
    font-family: "Jost", sans-serif;
  }
}
</style>
