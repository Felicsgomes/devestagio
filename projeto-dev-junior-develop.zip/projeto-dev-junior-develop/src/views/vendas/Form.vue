<template>
  <div class="container">
    <h1 class="title">{{ formTitle }}</h1>
    <form @submit.prevent="submitForm">
      <div class="form">
        <div class="form-group">
          <label>Cliente</label>
          <select class="input" v-model="formData.clientId" :disabled="isEditing">
            <option value="" disabled>Selecione um cliente</option>
            <option
              v-for="client in clients"
              :key="client.id"
              :value="client.id"
            >
              {{ client.name }}
            </option>
          </select>
        </div>
        <div class="form-group">
          <label>Data de faturamento</label>
          <input class="input" v-model="formData.billingDate" type="date" />
        </div>
      </div>

      <h2 class="title">Itens do pedido</h2>
      <div class="form">
        <div class="form-group">
          <label>Descrição do item</label>
          <input class="input" v-model="item.description" type="text" />
        </div>
        <div class="form-group">
          <label>Valor unitário</label>
          <input class="input" v-model.number="item.unitPrice" type="number" />
        </div>
        <div class="form-group">
          <label>Quantidade</label>
          <input class="input" v-model.number="item.qtdItems" type="number" />
        </div>
        <div class="form-group">
          <label>Valor total</label>
          <input
            class="input input-disabled"
            :value="formatPriceBRL(item.totalPrice)"
            type="text"
            readonly
          />
        </div>
      </div>

      <div class="form-group-button">
        <button type="button" class="button" @click="addItem">
          Adicionar Itens
        </button>
      </div>

      <Table v-show="rows.length" :headers="headers" :rows="formattedRows">
        <template v-slot:actions="{ index }">
          <Button @click="deleteItem(index)" class="btn-delete">Deletar</Button>
        </template>
      </Table>

      <div class="form-group-button-total">
        <span class="title-price-total">Total: {{ formatPriceBRL(totalPrice) }}</span>
        <div class="form-group-button">
          <Button type="submit" colorButton="green">Salvar</Button>
          <Button type="button" colorButton="red" @click="$emit('close')">
            Cancelar
          </Button>
        </div>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted } from "vue";
import Table from "@/components/Table/Table.vue";
import Button from "@/components/Button/Button.vue";
import axios from "axios";
import currency from "@/utils/currency";

const formatPriceBRL = (value) => {
  if (typeof value === 'number') {
    return currency(value);
  }
  return value;
};

const props = defineProps({
  sale: Object,
});

onMounted(() => {
  fetchClients();
});

const emit = defineEmits(["close"]);

const formData = ref({
  clientId: "",
  billingDate: "",
});

const item = ref({
  description: "",
  unitPrice: 0,
  qtdItems: 0,
  totalPrice: 0,
});

const headers = ref([
  { key: "description", label: "Descrição" },
  { key: "unitPrice", label: "Valor Unitário" },
  { key: "qtdItems", label: "Quantidade" },
  { key: "totalPrice", label: "Total" },
]);

const rows = ref([]);
const clients = ref([]);

const totalPrice = computed(() => {
  return rows.value
    .reduce((total, row) => total + row.totalPrice, 0);
});


const formattedRows = computed(() => {
  return rows.value.map(row => ({
    ...row,
    unitPrice: formatPriceBRL(row.unitPrice),
    totalPrice: formatPriceBRL(row.totalPrice),
  }));
});

const formTitle = computed(() => {
  return props.sale ? "Editar venda" : "Adicionar venda";
});

const isEditing = computed(() => !!props.sale);

async function fetchClients() {
  try {
    const response = await axios.get("http://localhost:3005/clients");
    clients.value = response.data;
  } catch (error) {
    console.error("Erro ao buscar clientes:", error);
  }
}

async function submitForm() {
  if (!formData.value.clientId || !formData.value.billingDate || rows.value.length === 0) {
    alert("Por favor, preencha todos os campos obrigatórios e adicione pelo menos um item.");
    return;
  }
  const payload = {
    clientId: formData.value.clientId,
    clientName: clients.value.find(
      (client) => client.id === formData.value.clientId
    )?.name,
    billingDate: formData.value.billingDate,
    qtdItems: rows.value.reduce((total, row) => total + row.qtdItems, 0),
    saleDate: new Date().toISOString().slice(0, 10),
    totalPrice: totalPrice.value,
    items: rows.value.map(row => ({
      description: row.description,
      unitPrice: row.unitPrice,
      qtdItems: row.qtdItems,
    }))
  };

  try {
    if (props.sale) {
      await axios.put(`http://localhost:3005/sales/${props.sale.id}`, payload);
    } else {
      await axios.post("http://localhost:3005/sales", payload);
    }
    emit("close");
  } catch (err) {
    console.error(err);
  }
}

function addItem() {
  if (item.value.description && item.value.unitPrice && item.value.qtdItems) {
    const unitPrice = parseFloat(item.value.unitPrice) || 0;
    const totalPrice = unitPrice * item.value.qtdItems;

    rows.value.push({
      description: item.value.description,
      unitPrice: unitPrice,
      qtdItems: item.value.qtdItems,
      totalPrice: totalPrice,
    });

    item.value = {
      description: "",
      unitPrice: 0,
      qtdItems: 0,
      totalPrice: 0,
    };
  } else {
    alert("Por favor, preencha todos os campos do item.");
  }
}

function deleteItem(index) {
  rows.value.splice(index, 1);
}

watch(
  [() => item.value.unitPrice, () => item.value.qtdItems],
  () => {
    const unitPrice = parseFloat(item.value.unitPrice) || 0;
    item.value.totalPrice = unitPrice * item.value.qtdItems;
  },
  { immediate: true }
);

watch(
  () => props.sale,
  (newSale) => {
    if (newSale) {
      formData.value = {
        clientId: newSale.clientId,
        billingDate: newSale.billingDate,
      };

      rows.value = newSale.items?.map(item => ({
        description: item.description || "",
        unitPrice: item.unitPrice,
        qtdItems: item.qtdItems || 0,
        totalPrice: item.unitPrice * item.qtdItems,
      })) || [];
    } else {
      formData.value = {
        clientId: "",
        billingDate: "",
      };

      rows.value = [];
    }
  },
  { immediate: true }
);
</script>


<style scoped>
.container {
  margin: 10px;
  background-color: #ffffff;
  border: solid 1px #e5ebf1;
  border-radius: 5px;
  box-shadow: 1px 1px 1px 1px #e5ebf1;
  padding: 35px;
}

.title {
  color: #26324b;
  font-size: 20px;
  font-weight: 700;
  font-family: "Jost", sans-serif;
  margin-bottom: 25px;
  margin-top: 20px;
}

.input {
  width: 100%;
  height: 38px;
  border: solid 1px #e5ebf1;
  border-radius: 5px;
  padding: 10px;
}

.form {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
}

.form-group {
  flex: 1 1 calc(50% - 20px);
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.form-group-button {
  display: flex;
  justify-content: flex-end;
  flex: 1 1 100%;
  padding: 10px;
  gap: 10px;
}

.form-group-button-total {
  display: flex;
  justify-content: space-between;
  gap: 20px;
  align-items: center;
  width: 100%;
  margin-top: 20px;
}

.title-price-total {
  width: 100%;
  color: #26324b;
  font-size: 24px;
  font-family: "Jost", sans-serif;
  font-weight: 700;
}

.button {
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #ffffff;
  padding: 10px 20px;
  color: #274a9d;
  font-size: 16px;
  font-family: "Jost", sans-serif;
  font-weight: 600;
  border-radius: 5px;
  border: solid 2px #274a9d;
  cursor: pointer;
}

@media (max-width: 600px) {
  .form-group {
    flex: 1 1 100%;
  }

  .form-group-button-total {
    flex-direction: column;
    align-items: flex-start;
  }

  .title-price-total {
    margin-bottom: 15px;
  }
}

.btn-delete {
  padding: 9px;
  background-color: #fdf6f6;
  color: #c27476;
  border-radius: 5px;
  font-weight: 500;
  font-size: 14px;
  font-family: "Jost", sans-serif;
  cursor: pointer;
}

.input-disabled {
  background-color: #f0f0f0;
  color: #a0a0a0;
  cursor: not-allowed;
}
</style>
