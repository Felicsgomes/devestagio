<template>
  <div v-if="!openForm">
    <div class="container-search">
        <div class="search-wrapper">
          <input
            type="search"
            name="search"
            class="input-search"
            v-model="searchTerm"
            placeholder="Pesquisar..."
          />
          <SearchIcon class="search-icon" />
        </div>
      </div>
    <div class="container-button">
      <Button colorButton="green" @click="activeOpenForm">Adicionar</Button>
    </div>
    <Table :headers="headers" :rows="filteredRows">
      <template v-slot:actions="{ row }">
        <button
          @click="editSale(row.id)"
          class="btn-edit"
          aria-label="Editar Venda"
        >
          Editar
        </button>
        <button
          @click="deleteSale(row.id)"
          class="btn-delete"
          aria-label="Deletar Venda"
        >
          Deletar
        </button>
      </template>
    </Table>
  </div>
  <div v-if="openForm">
    <Form :sale="selectedSale" @close="toggleForm" />
  </div>
</template>

<script setup>
import { ref, watch, onMounted, computed } from "vue";
import axios from "axios";
import Table from "@/components/Table/Table.vue";
import Button from "@/components/Button/Button.vue";
import Form from "@/views/vendas/Form.vue";
import { formatDateBRL, formatPriceBRL } from "@/utils/format";
import SearchIcon from "@/components/icons/SearchIcon.vue";

const openForm = ref(false);
const selectedSale = ref(null);

const activeOpenForm = () => {
  openForm.value = true;
};

const headers = ref([
  { key: "id", label: "ID" },
  { key: "clientName", label: "Cliente" },
  { key: "qtdItems", label: "Qtd. itens" },
  { key: "saleDate", label: "Data da venda" },
  { key: "billingDate", label: "Data Faturamento" },
  { key: "totalPrice", label: "Valor total" },
]);

const rows = ref([]);
const searchTerm = ref("");
const formattedRows = computed(() =>
  rows.value.map(row => ({
    ...row,
    saleDate: formatDateBRL(row.saleDate),
    billingDate: formatDateBRL(row.billingDate),
    totalPrice: formatPriceBRL(row.totalPrice),
  }))
);


const filteredRows = computed(() => {
  const term = searchTerm.value.toLowerCase();
  return formattedRows.value.filter(row =>
    Object.values(row).some(value =>
      String(value).toLowerCase().includes(term)
    )
  );
});

async function getSales() {
  try {
    const res = await axios.get("http://localhost:3005/sales");
    rows.value = res.data;
  } catch (err) {
    console.error(err);
  }
}

async function editSale(id) {
  try {
    const res = await axios.get(`http://localhost:3005/sales/${id}`);
    selectedSale.value = res.data;
    activeOpenForm();
  } catch (err) {
    console.error(err);
  }
}

async function deleteSale(id) {
  if (confirm("Tem certeza de que deseja excluir esta venda?")) {
    try {
      await axios.delete(`http://localhost:3005/sales/${id}`);
      rows.value = rows.value.filter((sale) => sale.id !== id);
    } catch (err) {
      console.error(err);
    }
  }
}

function toggleForm() {
  openForm.value = !openForm.value;
  if (!openForm.value) {
    selectedSale.value = null;
  }
}

onMounted(getSales);
watch(openForm, getSales);
</script>

<style scoped>
.container-search {
  padding: 10px;
  width: 100%;
  display: flex;
  justify-content: end;
}

.search-wrapper {
  width: 30%;
  position: relative;
  display: flex;
  align-items: center;
}

.input-search {
  width: 100%;
  margin: 10px;
  padding: 10px;
  border-radius: 5px;
  padding-right: 40px;
}

.search-icon {
  position: absolute;
  right: 10px;
  font-size: 1.2em; 
  color: #999; 
}
.container-button {
  display: flex;
  justify-content: flex-end;
  margin: 20px;
}

.btn-edit {
  padding: 9px;
  background-color: #f6fafd;
  color: #5b89c7;
  border-radius: 5px;
  font-weight: 500;
  font-size: 14px;
  font-family: "Jost", sans-serif;
  cursor: pointer;
}

.btn-delete {
  padding: 9px;
  background-color: #fdf6f6;
  color: #c27476;
  border-radius: 5px;
  font-weight: 500;
  font-size: 14px;
  font-family: "Jost", sans-serif;
  cursor: pointer;
}
</style>
